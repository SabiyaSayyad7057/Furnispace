package com.example.Furnispace.Controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.Orders;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Entity.orderTransactionDetails;
import com.example.Furnispace.Repo.FurnitureRepo;
import com.example.Furnispace.Repo.OrderRepo;
import com.example.Furnispace.Service.orderServices;


import jakarta.servlet.http.HttpSession;

@RestController
public class paymentTransactionController 
{
	@Autowired
	private orderServices orderservices;
	
	@Autowired
	private FurnitureRepo frepo;
	
	@Autowired
	private OrderRepo orepo;
	@CrossOrigin(origins = "*")
	@GetMapping("/getTransaction/{amount}")
	public orderTransactionDetails getTransaction(@PathVariable(name="amount") double amount) {
        orderTransactionDetails transactionDetails = orderservices.orderCreateTransaction(amount);
        if (transactionDetails != null) {
            return transactionDetails;
        } else {
            // Handle error case
            return null;  // Return an error response, or you could throw a custom exception
        }
    }
	
	
	
	

}
