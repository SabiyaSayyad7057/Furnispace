package com.example.Furnispace.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
public class CartItems {
       
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "id") // map to existing DB column
		private int cartid;
		   
	   @Lob
       private String img;
       private String name;
       private double price;
       private int quantity;
       
//       private int id;
       
       @ManyToOne
       @JoinColumn(name = "f_id")
       @JsonBackReference
       private Furniture furniture;
       
       
       @ManyToOne
       @JoinColumn(name = "u_id")
       @JsonBackReference
       private User user;

       
			
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void incrementquantity()
	{
		this.quantity++;
	}
	
	public double gettotalprice()
	{
		return furniture.getPrice()*quantity;
	}

	
	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Furniture getFurniture() {
		return furniture;
	}

	public void setFurniture(Furniture furniture) {
		this.furniture = furniture;
	}

	public CartItems(int cartid, String img, String name, double price, int quantity, Furniture furniture, User user) {
		super();
		this.cartid = cartid;
		this.img = img;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.furniture = furniture;
		this.user = user;
	}

	public CartItems() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartItems(Furniture furniture2) {
		// TODO Auto-generated constructor stub
		
		this.furniture = furniture2;
	}

	@Override
	public String toString() {
		return "CartItems [cartid=" + cartid + ", img=" + img + ", name=" + name + ", price=" + price + ", quantity="
				+ quantity + ", furniture=" + furniture + ", user=" + user + "]";
	}

	
	
	
       
       
       
}
