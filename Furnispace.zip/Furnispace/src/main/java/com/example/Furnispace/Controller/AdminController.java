package com.example.Furnispace.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.UserRepo;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/admin")

public class AdminController {
	
	@Autowired
	private UserRepo urepo;
	
	public String about()
	{
		return "AAbout";
	}
	
	public String contact()
	{
		return "AContact";
	}
	
//	@GetMapping("/home")
//	public String userhome(HttpSession session, Model model)
//	{
//		User user = (User)session.getAttribute("loggedUser");
//		if(user != null && "ADMIN".equalsIgnoreCase(user.getRole()))
//		{
//			model.addAttribute("furniturelist",new ArrayList<>());
//			model.addAttribute("category","All");
//			return "home";
//		}
//		return "redirect:/login";
//	}
	
	
//	@GetMapping("/admin/customers")
//	public String viewCustomers(Model model) {
//	    List<User> customers = urepo.findByRole("ROLE_USER");
//	    model.addAttribute("customerList", customers);
//	    return "customers";
//	}

}
