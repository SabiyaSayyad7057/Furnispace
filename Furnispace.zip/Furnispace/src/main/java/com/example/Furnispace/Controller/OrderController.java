package com.example.Furnispace.Controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.Orders;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Entity.orderTransactionDetails;
import com.example.Furnispace.Repo.CartRepo;
import com.example.Furnispace.Repo.FurnitureRepo;
import com.example.Furnispace.Repo.OrderRepo;
import com.example.Furnispace.Service.EmailService;
import com.example.Furnispace.Service.orderServices;

import jakarta.persistence.criteria.Order;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
    private CartRepo crepo;

    @Autowired
    private OrderRepo orepo;
    
    @Autowired
    private FurnitureRepo frepo;
    
    @Autowired
    private orderServices orderservices;
    
    @Autowired
    private EmailService emailService;
    
 // OrderController.java
    @PostMapping("/create_order")
    @ResponseBody
    public ResponseEntity<orderTransactionDetails> createOrder(@RequestParam("price") double price) {
        orderTransactionDetails orderDetails = orderservices.orderCreateTransaction(price);
        return ResponseEntity.ok(orderDetails);
    }
 	
    @PostMapping("/save")
    @ResponseBody
    public ResponseEntity<String> saveOrderFromCart(@RequestBody Map<String, String> data, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }

        List<CartItems> cartItems = (List<CartItems>) session.getAttribute("cart");
        if (cartItems == null || cartItems.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Cart is empty");
        }

        try {
            double totalAmount = 0;
            StringBuilder orderSummary = new StringBuilder();

            for (CartItems item : cartItems) {
                Orders order = new Orders();
                order.setProductName(item.getName());
                order.setPrice(item.getPrice());
                order.setQuantity(item.getQuantity());
                order.setTotalPrice(item.getPrice() * item.getQuantity());
                order.setOrderTime(LocalDateTime.now());
                order.setUser(user);
                order.setFurniture(item.getFurniture());
                order.setImage(item.getImg());
                orepo.save(order);

                crepo.delete(item);

                // For email
                totalAmount += order.getTotalPrice();
                orderSummary.append("- ").append(item.getName())
                            .append(" (x").append(item.getQuantity()).append("): ₹")
                            .append(order.getTotalPrice()).append("\n");
            }

            session.setAttribute("cart", new ArrayList<CartItems>());

            // ✅ Send confirmation email
            String subject = "🧾 Order Confirmation - FurniSpace";
            String body = "Dear " + user.getName() + ",\n\nThank you for your purchase! Your order has been placed successfully.\n\n"
                    + "🛍️ Order Details:\n" + orderSummary
                    + "\nTotal: ₹" + totalAmount
                    + "\n\nYour products will be shipped soon.\n\nBest regards,\nFurniSpace Team";

            emailService.sendEmail(user.getEmail(), subject, body);

            return ResponseEntity.ok("Order placed successfully and email sent!");

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving order: " + e.getMessage());
        }
    }

    
//    @PostMapping("/save")
//    @ResponseBody
//    public ResponseEntity<String> saveOrderFromCart(@RequestBody Map<String, String> data, HttpSession session) {
//        User user = (User) session.getAttribute("loggedInUser");
//        if (user == null) {
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
//        }
//
//        // ✅ Get all cart items from DB for this user
//        List<CartItems> cartItems = crepo.findByUser(user);
//        if (cartItems == null || cartItems.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Cart is empty");
//        }
//
//        try {
//            for (CartItems item : cartItems) {
//                Orders order = new Orders();
//                order.setProductName(item.getName());
//                order.setPrice(item.getPrice());
//                order.setQuantity(item.getQuantity());
//                order.setTotalPrice(item.getPrice() * item.getQuantity());
//                order.setOrderTime(LocalDateTime.now());
//                order.setUser(user);
//                order.setFurniture(item.getFurniture());
//                order.setImage(item.getImg());
//
//                orepo.save(order);     // ✅ Save order
//                crepo.delete(item);    // ✅ Remove from DB cart
//            }
//
//            session.setAttribute("cart", new ArrayList<CartItems>()); // ✅ Clear session cart
//
//            return ResponseEntity.ok("All cart items ordered successfully");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving order: " + e.getMessage());
//        }
//    }

 	
 	@GetMapping("/orders")
 	public String viewOrders(Model model, HttpSession session) {
 	    User user = (User) session.getAttribute("loggedInUser");
  	    List<Orders> orders = orepo.findByUser(user);
 	    model.addAttribute("orders", orders);
 	    return "MyOrder";
 	}



   }
