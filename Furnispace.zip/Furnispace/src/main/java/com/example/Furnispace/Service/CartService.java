// CartService.java
package com.example.Furnispace.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.CartRepo;

@Service
@Transactional
public class CartService {
    
    @Autowired
    private CartRepo cartRepo;
    
    // Get all cart items for a user
    public List<CartItems> getCartItemsByUser(User user) {
        return cartRepo.findByUser(user);
    }
    
    // Get cart items by user and furniture
    public List<CartItems> getCartItemsByUserAndFurniture(User user, Furniture furniture) {
        return cartRepo.findByUserAndFurniture(user, furniture);
    }
    
    // Add item to cart
    public CartItems addToCart(User user, Furniture furniture) {
        // Check if item already exists
        List<CartItems> existingItems = cartRepo.findByUserAndFurniture(user, furniture);
        
        if (!existingItems.isEmpty()) {
            // Item exists, increment quantity
            CartItems existingItem = existingItems.get(0);
            existingItem.setQuantity(existingItem.getQuantity() + 1);
            return cartRepo.save(existingItem);
        } else {
            // Create new cart item
            CartItems newItem = new CartItems(furniture);
            newItem.setUser(user);
            newItem.setImg(furniture.getImg());
            newItem.setName(furniture.getName());
            newItem.setPrice(furniture.getPrice());
            newItem.setQuantity(1);
            return cartRepo.save(newItem);
        }
    }
    
    // Update cart item quantity
    public CartItems updateCartItemQuantity(int cartItemId, int newQuantity) {
        Optional<CartItems> optionalItem = cartRepo.findById(cartItemId);
        if (optionalItem.isPresent()) {
            CartItems item = optionalItem.get();
            if (newQuantity > 0) {
                item.setQuantity(newQuantity);
                return cartRepo.save(item);
            } else {
                cartRepo.delete(item);
                return null;
            }
        }
        return null;
    }
    
    // Increment quantity
    public CartItems incrementQuantity(User user, Furniture furniture) {
        List<CartItems> items = cartRepo.findByUserAndFurniture(user, furniture);
        if (!items.isEmpty()) {
            CartItems item = items.get(0);
            item.setQuantity(item.getQuantity() + 1);
            return cartRepo.save(item);
        }
        return null;
    }
    
    // Decrement quantity
    public CartItems decrementQuantity(User user, Furniture furniture) {
        List<CartItems> items = cartRepo.findByUserAndFurniture(user, furniture);
        if (!items.isEmpty()) {
            CartItems item = items.get(0);
            if (item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                return cartRepo.save(item);
            } else {
                cartRepo.delete(item);
                return null;
            }
        }
        return null;
    }
    
    // Remove item from cart
    public void removeFromCart(User user, Furniture furniture) {
        List<CartItems> items = cartRepo.findByUserAndFurniture(user, furniture);
        if (!items.isEmpty()) {
            for (CartItems item : items) {
                cartRepo.delete(item);
            }
        }
    }
    
    // Remove item by ID
    public void removeCartItem(int cartItemId) {
        cartRepo.deleteById(cartItemId);
    }
    
    // Clear entire cart for a user
    public void clearCartByUser(User user) {
        List<CartItems> userCartItems = cartRepo.findByUser(user);
        if (!userCartItems.isEmpty()) {
            cartRepo.deleteAll(userCartItems);
        }
    }
    
    // Calculate total price for user's cart
    public double calculateCartTotal(User user) {
        List<CartItems> cartItems = cartRepo.findByUser(user);
        return cartItems.stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
    }
    
    // Get total items count in cart
    public int getCartItemsCount(User user) {
        List<CartItems> cartItems = cartRepo.findByUser(user);
        return cartItems.stream()
                .mapToInt(CartItems::getQuantity)
                .sum();
    }
    
    // Check if item exists in cart
    public boolean isItemInCart(User user, Furniture furniture) {
        List<CartItems> items = cartRepo.findByUserAndFurniture(user, furniture);
        return !items.isEmpty();
    }
    
    // Get cart item by user and furniture (single item)
    public CartItems getCartItem(User user, Furniture furniture) {
        List<CartItems> items = cartRepo.findByUserAndFurniture(user, furniture);
        return items.isEmpty() ? null : items.get(0);
    }
    
    // Save cart item
    public CartItems saveCartItem(CartItems cartItem) {
        return cartRepo.save(cartItem);
    }
    
    // Get all cart items
    public List<CartItems> getAllCartItems() {
        return cartRepo.findAll();
    }
}