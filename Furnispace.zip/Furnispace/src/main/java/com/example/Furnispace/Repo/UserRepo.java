// Enhanced UserRepo.java - Additional methods
package com.example.Furnispace.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Furnispace.Entity.User;

@Repository
public interface UserRepo extends JpaRepository<User, Integer> {
    
    // Existing methods
    User findByEmailAndPassword(String email, String password);
    User findByUsername(String username);
    
    // Additional methods for enhanced functionality
    User findByEmail(String email);
    List<User> findByRole(String role);
    boolean existsByEmail(String email);
    boolean existsByUsername(String username);
    
    // Find users by name (case-insensitive)
    List<User> findByNameContainingIgnoreCase(String name);
    
    // Find users by phone number
    User findByPhone(String phone);
    
    // Find users by role and active status (if you have an active field)
    // List<User> findByRoleAndActive(String role, boolean active);
    
    // Custom query to find users with specific role
    @Query("SELECT u FROM User u WHERE u.role = :role")
    List<User> getUsersByRole(@Param("role") String role);
    
    // Custom query to find user by email or username
    @Query("SELECT u FROM User u WHERE u.email = :emailOrUsername OR u.username = :emailOrUsername")
    User findByEmailOrUsername(@Param("emailOrUsername") String emailOrUsername);
    
    // Count users by role
    long countByRole(String role);
    
    // Find users by address containing specific text
    List<User> findByAddressContainingIgnoreCase(String address);
}