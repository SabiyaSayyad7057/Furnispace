package com.example.Furnispace.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.Orders;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.CartRepo;
import com.example.Furnispace.Repo.FurnitureRepo;
import com.example.Furnispace.Repo.OrderRepo;
import com.example.Furnispace.Service.FurnitureService;
import com.example.Furnispace.Service.UserService;

import jakarta.servlet.http.HttpSession;



@Controller
@RequestMapping("/fur")
public class FurnitureController {
	
	@Autowired
	private FurnitureService fservice;
	@Autowired
	private FurnitureRepo frepo;
	
	@Autowired
	private CartRepo crepo;
	
	@Autowired
	private OrderRepo orepo;
	
	
	@Autowired UserService uservice;
	
	@GetMapping("/home")
	public String home()
	{
		return "AHomePage";
	}
	
	public String about()
	{
		return "AAbout";
	}
	
	public String contact()
	{
		return "AContact";
	}
	
	@GetMapping("/add")
	public String add(Model model) {
	    model.addAttribute("furnitures", new Furniture());
	    return "Add";
	}
	

	@PostMapping("/submit-item")
	public String submitFurnitureForm(
	        @RequestParam("name") String name,
	        @RequestParam("name_desc") String name_desc,
	        @RequestParam("price") double price,
	        @RequestParam("imagefile") MultipartFile img,
	        @RequestParam("category") String category) throws IOException {

	    Furniture furniture = new Furniture();
	    furniture.setName(name);
	    furniture.setPrice(price);
	    furniture.setCategory(category);
	    furniture.setName_desc(name_desc);

	    if (!img.isEmpty()) {
	        String base64Image = Base64.getEncoder().encodeToString(img.getBytes());
	        furniture.setImg(base64Image);
	    }

	    fservice.saveFurniture(furniture);
	    return "redirect:/fur/home";
	}
		
	@GetMapping("/category")
	public String getFurnitureByCategory(@RequestParam("name") String category, Model model)
	{
		
		List<Furniture> furniturelist = fservice.getFurnitureByCategory(category);
		model.addAttribute("category", category);
		model.addAttribute("furniturelist", furniturelist);
		
		return "ACategoryPage";
	}
		
	@GetMapping("/ucategory")
	public String getFurniturByCategory(@RequestParam("name") String category, Model model)
	{
		
		List<Furniture> furniturelist = fservice.getFurnitureByCategory(category);
		model.addAttribute("category", category);
		model.addAttribute("furniturelist", furniturelist);
		
		return "UCategoryPage";
	}
	
//	@GetMapping("/details/{id}")
//	public String viewProductDetails(@PathVariable int id, Model model,HttpSession session) {
//		User u = (User) session.getAttribute("loggedInUser");
//		List<CartItems> cart = crepo.findByUser(u); // or however you're fetching cart
//
//		model.addAttribute("uname",u.getName());
//		model.addAttribute("uemail",u.getEmail());
//		model.addAttribute("uphone",u.getPhone());
//	    Furniture fur = fservice.getFurnitureById(id);
//	    model.addAttribute("fur", fur);
//	    return "UViewDetails"; // This HTML page
//	}
	
//	@GetMapping("/details/{id}")
//	public String viewProductDetails(@PathVariable int id, Model model, HttpSession session) {
//	    User u = (User) session.getAttribute("loggedInUser");
//
//	    // Handle case when user is not logged in
//	    if (u == null) {
//	        return "redirect:/login"; // or any page you want to redirect to
//	    }
//
//	    List<CartItems> cart = crepo.findByUser(u);
//
//	    model.addAttribute("uname", u.getName());
//	    model.addAttribute("uemail", u.getEmail());
//	    model.addAttribute("uphone", u.getPhone());
//
//	    Furniture fur = fservice.getFurnitureById(id);
//	    model.addAttribute("fur", fur);
//	    model.addAttribute("cart", cart);
//
//	    return "UViewDetails";
//	}
//	
	
	@GetMapping("/details/{id}")
	public String viewProductDetails(@PathVariable int id, Model model, HttpSession session) {
	    User u = (User) session.getAttribute("loggedInUser");

	    // ✅ Redirect if user not logged in
	    if (u == null) {
	        return "redirect:/login"; // or error page
	    }

	    List<CartItems> cart = crepo.findByUser(u);

	    model.addAttribute("uname", u.getName());
	    model.addAttribute("uemail", u.getEmail());
	    model.addAttribute("uphone", u.getPhone());

	    Furniture fur = fservice.getFurnitureById(id);
	    model.addAttribute("fur", fur);
	    model.addAttribute("cart", cart); // for cart badge if needed

	    return "UViewDetails"; // ✅ Ensure this HTML file exists in /templates
	}
	
	@GetMapping("/aproducts")
    public String showAllProduct(Model model) {
        List<Furniture> furnitureList = frepo.findAll();
        model.addAttribute("furniturelist", furnitureList);
        return "AProducts"; // the name of your products HTML file without .html
    }
	
	@GetMapping("/products")
	public String showAllProducts(Model model, HttpSession session) {
	    List<Furniture> furnitureList = frepo.findAll();
	    model.addAttribute("furniturelist", furnitureList);

	    // ✅ Inject cart items for navbar badge
	    List<CartItems> cart = (List<CartItems>) session.getAttribute("cart");
	    model.addAttribute("cart", cart != null ? cart : new ArrayList<>());

	    return "UProducts";
	}

		
//	@GetMapping("/products")
//    public String showAllProducts(Model model) {
//        List<Furniture> furnitureList = frepo.findAll();
//        model.addAttribute("furniturelist", furnitureList);
//        return "UProducts"; // the name of your products HTML file without .html
//    }
	
	@GetMapping("/edit/{id}")
	public String editFurnitureForm(@PathVariable("id") int id, Model model)  //page linking
	{
		System.out.println("inside edit");
		Furniture furniturel = fservice.getFurnitureById(id);
		model.addAttribute("furniture", furniturel);
		return "Update";
	}
	
	@PostMapping("/update")
	public String updateFurniture(@ModelAttribute Furniture furniture,
	                              @RequestParam("imagefile") MultipartFile imageFile) {
	    try {
	        if (!imageFile.isEmpty()) {
	            byte[] imageBytes = imageFile.getBytes();
	            String base64Image = Base64.getEncoder().encodeToString(imageBytes);
	            furniture.setImg(base64Image);
	        }
	        fservice.updatefurniture(furniture);
	        return "redirect:/fur/category?name=" + furniture.getCategory();
	    } catch (IOException e) {
	        e.printStackTrace();
	        return "error"; // fallback page
	    }
	}

	
	
	@GetMapping("/delete/{id}")
	public String deletefurniture(@PathVariable("id") int id, Furniture f)   //path variable is used to extract values from URL path and bind them to method parameters in contro(suppose you want to fetch a user by their ID from URL)
	{
		fservice.deletefurniture(id);
		return "redirect:/fur/home";
	}
	
	
	
//	@GetMapping("/dashboard")
//	public String dashboard(Model model)
//	{
//		model.addAttribute("total", fservice.gettotal());
//		model.addAttribute("totaluser", uservice.gettotaluser());
//		model.addAttribute("totalcategory", fservice.gettotalcategory());
//		return "ADashboard";
//	}
	
	@GetMapping("/dashboard")
	public String showDashboard(Model model) {
//	    List<Orders> orders = orepo.findTop5ByOrderByOrderTimeDesc(); // or findAll()
//	    model.addAttribute("orders", orders);

	    model.addAttribute("total", frepo.count());
	    model.addAttribute("totaluser", uservice.gettotaluser());
	    model.addAttribute("totalcategory", fservice.gettotalcategory());
	    model.addAttribute("totalorders", orepo.countTotalOrders());
	    
	 // This line fetches ALL ORDERS for admin
	    List<Orders> orders = orepo.findAll();
	    model.addAttribute("orders", orders);
	       
        return "ADashboard";
	}

	
	@GetMapping("/service")
	public String service()
	{
		return "Service";
	}
	
		
	@GetMapping("/viewalluser")
	public String viewalluser(Model model)
	{
		
		model.addAttribute("user", uservice.getalluser());
		return "viewalluser";
	}
	
	
	

	   

	    @GetMapping("/order-history")
	    public String viewAllOrders(Model model) {
	        List<Orders> orders = orepo.findAll();
	        model.addAttribute("orders", orders);
	        return "Aorderhistory"; // HTML file name
	    }
	

	
	

}
