package com.example.Furnispace.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;

@Entity
public class Orders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    private String productName;
	    private double price;
	    private int quantity;

	    private double totalPrice;

	    private LocalDateTime orderTime;
        
	    
	    @ManyToOne
	    @JoinColumn(name = "u_id")
	    @JsonBackReference
	    private User user;
	    
	    @ManyToOne
	    @JoinColumn(name = "f_id")
	    @JsonBackReference
	    private Furniture furniture;
	    
//	    private String status = "Pending"; // can be: Pending, Delivered, Cancelled
//        
//	    
//	    
//	    
//
//	    public String getStatus() {
//			return status;
//		}
//
//
//
//		public void setStatus(String status) {
//			this.status = status;
//		}



		// Add image field if needed
	    @Lob
	    private String image;



		public int getId() {
			return id;
		}



		public void setId(int id) {
			this.id = id;
		}



		public String getProductName() {
			return productName;
		}



		public void setProductName(String productName) {
			this.productName = productName;
		}



		public double getPrice() {
			return price;
		}



		public void setPrice(double price) {
			this.price = price;
		}



		public int getQuantity() {
			return quantity;
		}



		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}



		public double getTotalPrice() {
			return totalPrice;
		}



		public void setTotalPrice(double totalPrice) {
			this.totalPrice = totalPrice;
		}



		public LocalDateTime getOrderTime() {
			return orderTime;
		}



		public void setOrderTime(LocalDateTime orderTime) {
			this.orderTime = orderTime;
		}



		public User getUser() {
			return user;
		}



		public void setUser(User user) {
			this.user = user;
		}



		public Furniture getFurniture() {
			return furniture;
		}



		public void setFurniture(Furniture furniture) {
			this.furniture = furniture;
		}



		public String getImage() {
			return image;
		}



		public void setImage(String image) {
			this.image = image;
		}



		public Orders(int id, String productName, double price, int quantity, double totalPrice,
				LocalDateTime orderTime, User user, Furniture furniture, String image) {
			super();
			this.id = id;
			this.productName = productName;
			this.price = price;
			this.quantity = quantity;
			this.totalPrice = totalPrice;
			this.orderTime = orderTime;
			this.user = user;
			this.furniture = furniture;
			this.image = image;
		}



		public Orders() {
			super();
			// TODO Auto-generated constructor stub
		}



		@Override
		public String toString() {
			return "Orders [id=" + id + ", productName=" + productName + ", price=" + price + ", quantity=" + quantity
					+ ", totalPrice=" + totalPrice + ", orderTime=" + orderTime + ", user=" + user + ", furniture="
					+ furniture + ", image=" + image + "]";
		}

		


}
