// Enhanced UserService.java - Additional methods for cart functionality
package com.example.Furnispace.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.UserRepo;

@Service
@Transactional
public class UserService {
    
    @Autowired
    private UserRepo userRepo;
    
    // Existing methods
    public long countAllCustomers() {
        return userRepo.count();
    }
    
    public User findByUsername(String username) {
        return userRepo.findByUsername(username);
    }
    
    public void updateUser(User updatedUser, String username) {
        User existingUser = userRepo.findByUsername(username);
        if (existingUser != null) {
            existingUser.setName(updatedUser.getName());
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setPhone(updatedUser.getPhone());
            existingUser.setAddress(updatedUser.getAddress());
            userRepo.save(existingUser);
        }
    }
    
    public List<User> getalluser() {
        return userRepo.findAll();
    }
    
    public Object gettotaluser() {
        return userRepo.count();
    }
    
    // Additional methods for cart functionality
    public User findById(int id) {
        Optional<User> user = userRepo.findById(id);
        return user.orElse(null);
    }
    
    public User findByEmail(String email) {
        return userRepo.findByEmail(email);
    }
    
    public User saveUser(User user) {
        return userRepo.save(user);
    }
    
    public void deleteUser(int id) {
        userRepo.deleteById(id);
    }
    
    public boolean existsById(int id) {
        return userRepo.existsById(id);
    }
    
    public User authenticateUser(String email, String password) {
        return userRepo.findByEmailAndPassword(email, password);
    }
    
    public List<User> findByRole(String role) {
        return userRepo.findByRole(role);
    }
    
    public boolean existsByEmail(String email) {
        return userRepo.existsByEmail(email);
    }
    
    public boolean existsByUsername(String username) {
        return userRepo.existsByUsername(username);
    }
}