package com.example.Furnispace.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Furnispace.Entity.Orders;
import com.example.Furnispace.Entity.User;

import jakarta.persistence.criteria.Order;

@Repository
public interface OrderRepo extends JpaRepository<Orders, Integer>{

	List<Orders> findByUser(User user);
	
	 List<Orders> findAll(); // Default method – fetches all orders

	List<Orders> findTop5ByOrderByOrderTimeDesc();

//	Object totalorder();
	
//	@Query("SELECT COUNT(o) FROM Orders o")
//    long countTotalOrders();
	
	 @Query("SELECT COUNT(o) FROM Orders o")
	    long countTotalOrders();
}
