// Enhanced CartRepo.java
package com.example.Furnispace.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.User;

@Repository
public interface CartRepo extends JpaRepository<CartItems, Integer> {
    
    // Find all cart items for a specific user
    List<CartItems> findByUser(User user);
    
    // Find cart items by user and furniture
    List<CartItems> findByUserAndFurniture(User user, Furniture furniture);
    
    // Find cart items by user ID
    List<CartItems> findByUserId(int userId);
    
    // Find cart items by furniture ID
    List<CartItems> findByFurnitureId(int furnitureId);
    
    // Delete all cart items for a user
    void deleteByUser(User user);
    
    // Delete cart items by user and furniture
    void deleteByUserAndFurniture(User user, Furniture furniture);
    
    // Count cart items for a user
    int countByUser(User user);
    
    // Check if cart item exists for user and furniture
    boolean existsByUserAndFurniture(User user, Furniture furniture);
    
    // Find cart item by user and furniture (single result)
    Optional<CartItems> findFirstByUserAndFurniture(User user, Furniture furniture);
    
    // Custom query to get total cart value for a user
    @Query("SELECT SUM(c.price * c.quantity) FROM CartItems c WHERE c.user = :user")
    Double getTotalCartValue(@Param("user") User user);
    
    // Custom query to get total quantity for a user
    @Query("SELECT SUM(c.quantity) FROM CartItems c WHERE c.user = :user")
    Integer getTotalQuantity(@Param("user") User user);
    
    // Find cart items with quantity greater than specified value
    List<CartItems> findByUserAndQuantityGreaterThan(User user, int quantity);
    
    // Find cart items ordered by creation date (if you have a timestamp field)
    @Query("SELECT c FROM CartItems c WHERE c.user = :user ORDER BY c.cartid DESC")
    List<CartItems> findByUserOrderByCartIdDesc(@Param("user") User user);

}
