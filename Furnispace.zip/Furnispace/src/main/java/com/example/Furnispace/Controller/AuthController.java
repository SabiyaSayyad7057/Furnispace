package com.example.Furnispace.Controller;

import com.example.Furnispace.FurnispaceApplication;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.UserRepo;
import com.example.Furnispace.Service.EmailService;
import com.example.Furnispace.Service.FurnitureService;
import com.example.Furnispace.Service.UserService;

import jakarta.servlet.http.HttpSession;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/validation")
public class AuthController {

   
    
	@Autowired
    private UserRepo urepo;
	@Autowired
	private EmailService emailService;
		
//	@Autowired
//	private UserService uservice;
	
	@GetMapping("/land")
	public String land()
	{
		return "LandingPage";
	}
	
	@GetMapping("/register")
	public String register(Model model)
	{
		model.addAttribute("user", new User());
		return "RegisterPage";
		
	}
	
	@GetMapping("/login")
	public String login(Model model)
	{
		model.addAttribute("user", new User());
		return "LoginPage";
	}
	
	@PostMapping("/register")
	public String adduser(@ModelAttribute User user, Model model)
	{
		try {
		user.setRole("USER");
		urepo.save(user);
		// ✅ Send welcome email here
		try {
		emailService.sendEmail(
		user.getEmail(),
		"Account created successfully!",
		"Welcome to Furnispace. Continue your bank journey... Thank you!"
		);
		} catch (Exception emailEx) {
		emailEx.printStackTrace();
		model.addAttribute("error", "Account created, but failed to send confirmation email.");
		return "RegisterPage"; // Optional: redirect anyway or show success
		}

		return "redirect:/validation/login?success=true";
		} catch (DataIntegrityViolationException e) {
		model.addAttribute("error", "Email or username already exists");
		return "RegisterPage";
		} catch (Exception e) {
		model.addAttribute("error", "An error occurred while creating your account");
		return "RegisterPage";	
		}
		
	}
	
	
	
	@PostMapping("/login")
	public String loginuser(@RequestParam String email, @RequestParam String password, Model model, HttpSession session)
	{
		System.out.println("Email: "+email +" password: "+password);
		
		User u = urepo.findByEmailAndPassword(email, password);
		if(u != null)
		{
			session.setAttribute("loggedInUser", u);
			
			if("ADMIN".equalsIgnoreCase(u.getRole()))
			{
				return "redirect:/fur/dashboard";
			}
			else
			{
				return "redirect:/users/home";
			}
		}
		else
		{
			model.addAttribute("error", "Invalid credentials");
			return "login";
		}
	}
	
//	@PostMapping("/login")
//	public String loginUser(@ModelAttribute User user, HttpSession session, Model model) {
//	    User existingUser = urepo.findByEmailAndPassword(user.getEmail(), user.getPassword());
//	    if (existingUser != null) {
//	        session.setAttribute("loggedInUser", existingUser); // ✅ Set the user in session
//	        return "redirect:/users/home";
//	    } else {
//	        model.addAttribute("error", "Invalid credentials");
//	        return "LoginPage";
//	    }
//	}

	
	@GetMapping("/logouts")
	public String log()
	{
		return "ULogout";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "redirect:/validation/land";
		
	}
	
//	@GetMapping("")
//	public String test(Model model)
//	{
//		model.addAttribute("total", fs.gettotal());
//		return "redirect:/fur/dashboard";
//	}
	
		
	
	

	

}
