package com.example.Furnispace.Controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.CartRepo;
import com.example.Furnispace.Repo.FurnitureRepo;
import com.example.Furnispace.Repo.UserRepo;
import com.example.Furnispace.Service.CartService;
import com.example.Furnispace.Service.FurnitureService;
import com.example.Furnispace.Service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	private UserRepo urepo;
	@Autowired
	private UserService uservice;
	@Autowired
	private FurnitureService fservice;
	
	@Autowired
	private CartService cservice;
	
	@Autowired
	private FurnitureRepo frepo;
	
	@Autowired
	private CartRepo crepo;
	
	
	
	@GetMapping("/home")
	public String userhome(HttpSession session, Model model, Principal principal)
	{
		User user = (User)session.getAttribute("loggedInUser");
		

		if(user != null && "USER".equalsIgnoreCase(user.getRole()))
		{
			return "UHomePage";
		}
		
		return "redirect:/LoginPage";
	}
	
	

	
	
	@GetMapping("/about")
	public String about()
	{
		return "About";
	}
	
	@GetMapping("/contact")
	public String contact()
	{
		return "Contact";
	}
	
	

	
	@GetMapping("/profile")
	public String showProfile(Model model, HttpSession session) {
	    User sessionUser = (User) session.getAttribute("loggedInUser");

	    if (sessionUser == null) {
	        return "redirect:/login";
	    }

	    int userId = sessionUser.getId(); // Get the ID from session
	    User dbUser = urepo.findById(userId).orElse(null); // Fetch latest user from DB

	    if (dbUser == null) {
	        return "redirect:/login"; // Or handle error appropriately
	    }

	    model.addAttribute("user", dbUser);
	    return "Profile";
	}

	
	@PostMapping("/update-profile")
	public String updateProfile(@ModelAttribute("user") User updatedUser, HttpSession session) {
	    User sessionUser = (User) session.getAttribute("loggedInUser");

	    if (sessionUser == null) {
	        return "redirect:/login";
	    }

	    updatedUser.setId(sessionUser.getId()); // Preserve ID
	    updatedUser.setUsername(sessionUser.getUsername()); // Prevent changing username
	    updatedUser.setRole(sessionUser.getRole()); // Prevent changing role
	   
	    urepo.save(updatedUser);

	    // Refresh session data
	    session.setAttribute("loggedInUser", updatedUser);

	    return "redirect:/users/home";
	}
	
//	@GetMapping("/addtocart")
//	public String addToCart(@RequestParam ("id") int id, HttpSession session)
//	{
//		User sessionUser = (User) session.getAttribute("loggedInUser");
//		Furniture furniture = fservice.getFurnitureById(id);
//		if(furniture == null || sessionUser == null)
//		{
//			return "redirect:/users/home";
//		}
////		to start session of cart
//		List<CartItems>	cart = (List<CartItems>) session.getAttribute("cart");
//		if(cart == null)
//		{
//			cart = new ArrayList<>();
//		}
//		boolean found = false;
//		for(CartItems c: cart)
//			if(c.getFurniture().getId() == furniture.getId() && c.getUser().getId() == sessionUser.getId())
//			{
//				c.incrementquantity();
//				crepo.save(c);
//				found = true;
//				break;
//			}
//		
//		//if not present then add
//		if(!found)
//		{
//			CartItems c = new CartItems(furniture);
//			c.setUser(sessionUser);
//			c.setImg(furniture.getImg());
//			c.setName(furniture.getName());
//			c.setPrice(furniture.getPrice());
//			c.setQuantity(1);
//			cart.add(c);
//			crepo.save(c);
//		}
//		
//		//start session of cart
//		session.setAttribute("cart", cart);     //"cart" object of html page
//		
//		return "redirect:/users/cart";
//		
//	}
	
//	@GetMapping("/cart")
//	public String viewcart(HttpSession session, Model model)
//	{
////User user;
//				List<CartItems> cart = (List<CartItems>) session.getAttribute("cart");
//		model.addAttribute("cart", cart != null ? cart : new ArrayList<>());
//		
////		List<CartItems> cart = crepo.findByUser(user);
////		double grandTotal = cart.stream().mapToDouble(c -> c.getPrice() * c.getQuantity()).sum();
////		model.addAttribute("cart", cart);
////		model.addAttribute("grandtotal", grandTotal);
//
//		
//		double grandtotal = 0;
//		for(CartItems item : cart)
//		{
//			grandtotal = grandtotal + item.getFurniture().getPrice()*item.getQuantity();
//		}
//		
//		model.addAttribute("grandtotal" , grandtotal);
//		model.addAttribute("cart" , cart);
//		
//		return "UserCart";
//	}
	
	
//	@GetMapping("/cart")
//	public String showCart(Model model, HttpSession session) {
//	    User user = (User) session.getAttribute("loggedInUser");
//
//	    if (user == null) {
//	        return "redirect:/login"; // or handle unauthorized access
//	    }
//
//	    List<CartItems> cart = crepo.findByUser(user);
//	    double grandTotal = cart.stream().mapToDouble(c -> c.getPrice() * c.getQuantity()).sum();
//
//	    model.addAttribute("cart", cart);
//	    model.addAttribute("grandtotal", grandTotal);
//
//	    return "UserCart";
//	}

	
//	@GetMapping("/removeitem")
//	public String removeitem(@RequestParam("id") int id, HttpSession session)
//	{
//		List<CartItems> cart = (List<CartItems>) session.getAttribute("cart");
//		if(cart != null)
//		{
//			Iterator<CartItems> i = cart.iterator();
//			while(i.hasNext())
//			{
//				CartItems item = i.next();
//				if(item.getFurniture().getId() == id)
//				{
//					i.remove();
//					crepo.delete(item);
//					break;
//				}
//			}
//		}
//		session.setAttribute("cart", cart);
//		return "redirect:/users/cart";
//	}
	
	
	@PostMapping("/users/clearCartAfterPurchase")
	public ResponseEntity<?> clearCartAfterPurchase(HttpSession session) {
	    User user = (User) session.getAttribute("user");
	    if (user == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	    }

	    cservice.clearCartByUser(user);
	    return ResponseEntity.ok("Cart cleared successfully");
	}
	
//	@PostMapping("/decrementQuantity")
//	public String decrementQuantity(@RequestParam("id") int id, HttpSession session) {
//	    User user = (User) session.getAttribute("loggedInUser");
//	    
//	    if (user == null) {
//	        return "redirect:/login";
//	    }
//	    
//	    Furniture furniture = frepo.findById(id).orElse(null);
//	    if (furniture == null) {
//	        return "redirect:/users/cart";
//	    }
//	    
//	    List<CartItems> items = crepo.findByUserAndFurniture(user, furniture);
//	    
//	    if (items != null && !items.isEmpty()) {
//	        CartItems cartItem = items.get(0);
//	        
//	        if (cartItem.getQuantity() > 1) {
//	            cartItem.setQuantity(cartItem.getQuantity() - 1);
//	            crepo.save(cartItem);
//	        } else {
//	            // Remove item if quantity would become 0
//	            crepo.delete(cartItem);
//	        }
//	        
//	        // Update session cart
//	        List<CartItems> updatedCart = crepo.findByUser(user);
//	        session.setAttribute("cart", updatedCart);
//	    }
//	    
//	    return "redirect:/users/cart";
//	}

	
	
//	@PostMapping("/decrease/{id}")
//	public String decreaseQuantity(@PathVariable("id") int id) {
//	    CartItems item = crepo.findById(id).orElse(null);
//	    if (item != null && item.getQuantity() > 1) {
//	        item.setQuantity(item.getQuantity() - 1);
//	        crepo.save(item);
//	    }
//	    return "redirect:/user/cart";
//	}
	
	// Replace your existing cart-related methods with these fixed versions

	@GetMapping("/cart")
	public String viewcart(HttpSession session, Model model) {
	    User sessionUser = (User) session.getAttribute("loggedInUser");
	    
	    if (sessionUser == null) {
	        return "redirect:/login";
	    }
	    
	    // Load cart from database instead of session
	    List<CartItems> cart = crepo.findByUser(sessionUser);
	    
	    // Update session with latest cart data
	    session.setAttribute("cart", cart);
	    
	    double grandtotal = 0;
	    if (cart != null) {
	        for (CartItems item : cart) {
	            grandtotal += item.getFurniture().getPrice() * item.getQuantity();
	        }
	    }
	    
	    model.addAttribute("grandtotal", grandtotal);
	    model.addAttribute("cart", cart != null ? cart : new ArrayList<>());
	    
	    return "UserCart";
	}

	@GetMapping("/addtocart")
	public String addToCart(@RequestParam("id") int id, HttpSession session) {
	    User sessionUser = (User) session.getAttribute("loggedInUser");
	    Furniture furniture = fservice.getFurnitureById(id);
	    
	    if (furniture == null || sessionUser == null) {
	        return "redirect:/users/home";
	    }
	    
	    // Check if item already exists in database
	    List<CartItems> existingItems = crepo.findByUserAndFurniture(sessionUser, furniture);
	    
	    if (!existingItems.isEmpty()) {
	        // Item exists, increment quantity
	        CartItems existingItem = existingItems.get(0);
	        existingItem.setQuantity(existingItem.getQuantity() + 1);
	        crepo.save(existingItem);
	    } else {
	        // Item doesn't exist, create new cart item
	        CartItems newItem = new CartItems(furniture);
	        newItem.setUser(sessionUser);
	        newItem.setImg(furniture.getImg());
	        newItem.setName(furniture.getName());
	        newItem.setPrice(furniture.getPrice());
	        newItem.setQuantity(1);
	        crepo.save(newItem);
	    }
	    
	    return "redirect:/users/cart";
	}

	@PostMapping("/incrementQuantity")
	public String incrementQuantity(@RequestParam("id") int id, HttpSession session) {
	    User user = (User) session.getAttribute("loggedInUser");
	    
	    if (user == null) {
	        return "redirect:/login";
	    }
	    
	    Furniture furniture = frepo.findById(id).orElse(null);
	    if (furniture == null) {
	        return "redirect:/users/cart";
	    }
	    
	    List<CartItems> items = crepo.findByUserAndFurniture(user, furniture);
	    
	    if (items != null && !items.isEmpty()) {
	        CartItems cartItem = items.get(0);
	        cartItem.setQuantity(cartItem.getQuantity() + 1);
	        crepo.save(cartItem);
	        
	        // Update session cart
	        List<CartItems> updatedCart = crepo.findByUser(user);
	        session.setAttribute("cart", updatedCart);
	    }
	    
	    return "redirect:/users/cart";
	}

	@PostMapping("/decrementQuantity")
	public String decrementQuantity(@RequestParam("id") int id, HttpSession session) {
	    User user = (User) session.getAttribute("loggedInUser");
	    
	    if (user == null) {
	        return "redirect:/login";
	    }
	    
	    Furniture furniture = frepo.findById(id).orElse(null);
	    if (furniture == null) {
	        return "redirect:/users/cart";
	    }
	    
	    List<CartItems> items = crepo.findByUserAndFurniture(user, furniture);
	    
	    if (items != null && !items.isEmpty()) {
	        CartItems cartItem = items.get(0);
	        
	        if (cartItem.getQuantity() > 1) {
	            cartItem.setQuantity(cartItem.getQuantity() - 1);
	            crepo.save(cartItem);
	        } else {
	            // Remove item if quantity would become 0
	            crepo.delete(cartItem);
	        }
	        
	        // Update session cart
	        List<CartItems> updatedCart = crepo.findByUser(user);
	        session.setAttribute("cart", updatedCart);
	    }
	    
	    return "redirect:/users/cart";
	}

	@GetMapping("/removeitem")
	public String removeitem(@RequestParam("id") int id, HttpSession session) {
	    User user = (User) session.getAttribute("loggedInUser");
	    
	    if (user == null) {
	        return "redirect:/login";
	    }
	    
	    Furniture furniture = frepo.findById(id).orElse(null);
	    if (furniture != null) {
	        List<CartItems> items = crepo.findByUserAndFurniture(user, furniture);
	        
	        if (!items.isEmpty()) {
	            for (CartItems item : items) {
	                crepo.delete(item);
	            }
	        }
	    }
	    
	    // Update session cart
	    List<CartItems> updatedCart = crepo.findByUser(user);
	    session.setAttribute("cart", updatedCart);
	    
	    return "redirect:/users/cart";
	}


}
