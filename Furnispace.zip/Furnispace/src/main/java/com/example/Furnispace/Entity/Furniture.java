package com.example.Furnispace.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;

//import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;

@Entity
public class Furniture {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String name;
	private String name_desc;
	private double price;
	private String actualprice;
	private String category;
	private int qty;
	
	
	
	public String getActualprice() {
		return actualprice;
	}
	public void setActualprice(String actualprice) {
		this.actualprice = actualprice;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Lob
	private String img;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getName_desc() {
		return name_desc;
	}
	public void setName_desc(String name_desc) {
		this.name_desc = name_desc;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public Furniture(int id, String name, String name_desc, double price, String actualprice, String category, int qty,
			String img) {
		super();
		this.id = id;
		this.name = name;
		this.name_desc = name_desc;
		this.price = price;
		this.actualprice = actualprice;
		this.category = category;
		this.qty = qty;
		this.img = img;
	}
	public Furniture() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Furniture [id=" + id + ", img=" + img + ", name_desc=" + name_desc + ", price=" + price + ", category="
				+ category + "]";
	}
	
	
	@JsonManagedReference
    @OneToMany(mappedBy = "furniture", cascade = CascadeType.ALL)
    private List<CartItems> cartItem;
	
	public List<CartItems> getCartItem()
	{
		return cartItem;
	}
	
	public void setCartItem(List<CartItems> cartItem)
	{
		this.cartItem = cartItem;
	}
	
	@JsonManagedReference
	@OneToMany(mappedBy = "furniture", cascade = CascadeType.ALL)
	private List<Orders> orders;



	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	
	
	
	


}
