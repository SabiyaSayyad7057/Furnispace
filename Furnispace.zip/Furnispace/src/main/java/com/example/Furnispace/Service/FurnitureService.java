package com.example.Furnispace.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.User;
import com.example.Furnispace.Repo.CartRepo;
import com.example.Furnispace.Repo.FurnitureRepo;
import com.example.Furnispace.Repo.OrderRepo;

@Service
public class FurnitureService {
	
	@Autowired
	private FurnitureRepo frepo;
	
	@Autowired
	private CartRepo cartrepo;
	
	@Autowired
	private OrderRepo orepo;

	public void submitFurnitureForm(Furniture furn) {
		// TODO Auto-generated method stub
		frepo.save(furn);
		
	}

	public List<Furniture> getFurnitureByCategory(String category) {
		// TODO Auto-generated method stub
		return frepo.findByCategoryIgnoreCase(category);
	}
	
	public List<Furniture> getFurniturByCategory(String category) {
		// TODO Auto-generated method stub
		return frepo.findByCategoryIgnoreCase(category);
	}
	
	public List<Furniture> getAllFurniture()
	{
		return frepo.findAll();
	}

	public Furniture getFurnitureById(int id)
	{
		return frepo.findById(id).orElse(null);
	}
	
	public void updatefurniture(Furniture furniture)
	{
		frepo.save(furniture);
	}
	
	public void deletefurniture(int id)
	{
		frepo.deleteById(id);
	}

	public void saveFurniture(Furniture furniture) {
		// TODO Auto-generated method stub
	     frepo.save(furniture);
		
	}

	public Object gettotal() {
		// TODO Auto-generated method stub
		return frepo.count();
	}

	public Object gettotalcategory() {
		// TODO Auto-generated method stub
		return frepo.totalCategory();
	}

//	public Object gettotalorder() {
//		// TODO Auto-generated method stub
//		return orepo.totalorder();
//	}

	
	
	


	


	
}
