package com.example.Furnispace.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Furnispace.Entity.CartItems;
import com.example.Furnispace.Entity.Furniture;
import com.example.Furnispace.Entity.User;

@Repository
  public interface FurnitureRepo extends JpaRepository<Furniture, Integer>{

	List<Furniture> findByCategoryIgnoreCase(String category);
	
	 @Query("SELECT COUNT(DISTINCT f.category) FROM Furniture f")
	 int totalCategory();
     
//	 @Query("select count)
//	Object gettotalorder();
//	 
//	 
//	List<Furniture> findByCategoryIgnoreCase(String category);
	 
//	 CartItems findByUserAndFurniture(User user, Furniture furniture);

	
}
