package com.example.Furnispace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FurnispaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
